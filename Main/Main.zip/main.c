#include "main.h"

#include "stm32f10x_pwr.h"
#include "usb_lib.h"
#include "usb_desc.h"
#include "hw_config.h"
#include "usb_pwr.h"
#include "ffconf.h"
#include "diskio.h"
#include "ff.h"

#include "usb_istr.h"


void Led_Blink(uint16_t how_much, uint16_t period);
void Spi_Set_Speed(uint8_t Speed);
void SPI_Config(void);
void Sd_work(void);

uint16_t Led_Flag;
uint8_t button_press, state;


int main(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;

	
	SysConfig();
	
// init Wake_up pin 
	PWR->CSR |= PWR_CSR_EWUP;
	
	Interrupt_Button_Config ();
	
	SysTick_Config(SystemFrequency / 1000);
	
	
	
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	  	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
  		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	  	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
  /*Set PA11,12 as IN - USB_DM,DP*/
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  /*SET PA11,12 for USB: USB_DM,DP*/
//  GPIO_PinAFConfig(GPIOA, GPIO_PinSource11, GPIO_AF_14);
//  GPIO_PinAFConfig(GPIOA, GPIO_PinSource12, GPIO_AF_14);
  
  
  /* Configure the EXTI line 18 connected internally to the USB IP */
  EXTI_ClearITPendingBit(EXTI_Line18);
  EXTI_InitStructure.EXTI_Line = EXTI_Line18; 
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
	
  /* Select USBCLK source */
  RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_1Div5);
  
  /* Enable the USB clock */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, ENABLE);
	
//	Set_System();
//	Set_USBClock();
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, ENABLE);
	USB_Init();
	USB_Interrupts_Config();

	
			SPI_Config();

			Led_Blink(2, 30);
	

	while(1)
	{
		
			//	Led_Blink(5, 100);
		
		if (GPIO_ReadInputDataBit(SD_CD_GPIO_PORT, SD_CD_PIN) != 0)
			GPIO_SetBits(GPIOB, GPIO_Pin_7);
		else GPIO_ResetBits(GPIOB, GPIO_Pin_7);
			
		
//		PWR_EnterSTANDBYMode();
//		PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
				

			
// 		if (Led_Flag == 100)
// 		{
// 			Led_Flag = 0;
// 			if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_7) == Bit_SET)
// 				GPIO_ResetBits(GPIOB, GPIO_Pin_7);
// 			else GPIO_SetBits(GPIOB, GPIO_Pin_7);
// 		};
	}

}

void Sd_work(void)
{
	uint8_t Sd_flag;	
	DSTATUS res;
	FRESULT error_ff; 
	FATFS FATFS_Obj;

		Sd_flag = 1;
	
	while(Sd_flag)
	{
		if (button_press == 1)
			{
				button_press = 0;
				state++;
				
				switch(state)
				{
					case 0:
						break;
					case 1:
						res = disk_initialize(0);
						if (res == STA_NOINIT)
							{
								GPIO_SetBits(GPIOB, GPIO_Pin_7);
								while(1);
							}
						else 
							if (res == STA_NODISK)
								{
									Led_Blink(2, 100);
									state = 0;
								}
								else
									if (res == 0)
										Led_Blink(1, 30);
						break;
									
					case 2:
							error_ff = f_mount(0, &FATFS_Obj);
							if (error_ff == 0)
								Led_Blink(1, 30);
							else 
								{
									Led_Blink(2, 100);
									state = 1;
								}
						break;
					
					default: break;
				}
				
			}
		
		
		
	}
}
void SPI_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	SPI_InitTypeDef SPI_InitStructure;
	
	RCC_APB2PeriphClockCmd(SD_SPI_SCK_GPIO_CLK | SD_CD_GPIO_CLK, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = SD_CS_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(SD_CS_GPIO_PORT, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = SD_SPI_SCK_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(SD_SPI_SCK_GPIO_PORT, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = SD_SPI_DI_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(SD_SPI_DI_GPIO_PORT, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = SD_SPI_DO_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(SD_SPI_DO_GPIO_PORT, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = SD_CD_PIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(SD_CD_GPIO_PORT, &GPIO_InitStructure);
	
	SPI_Cmd(SPI2, ENABLE);
	SPI_StructInit(&SPI_InitStructure);
	/* Initialize the SPI_Direction member */
  SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  /* initialize the SPI_Mode member */
  SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
  /* initialize the SPI_DataSize member */
  SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
  /* Initialize the SPI_BaudRatePrescaler member */
  SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_2;
  /* Initialize the SPI_FirstBit member */
  SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
  /* Initialize the SPI_CRCPolynomial member */
  SPI_InitStructure.SPI_CRCPolynomial = 7;
	
	SPI_Init(SPI2, &SPI_InitStructure);
}

void Spi_Set_Speed(uint8_t Speed)
{
	uint16_t tmpreg = 0;
	assert_param(IS_SPI_BAUDRATE_PRESCALER(Speed));
	
	tmpreg = SPI2->CR1;
	tmpreg &= ~(SPI_BaudRatePrescaler_256);// Clear prescaler
	tmpreg |= Speed;

}


void Interrupt_Button_Config (void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
  EXTI_InitTypeDef EXTI_InitStructure;
  NVIC_InitTypeDef NVIC_InitStructure;

  /* Enable the BUTTON Clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

  /* Configure Button pin as input */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* Connect Button EXTI Line to Button GPIO Pin */
//    SYSCFG_EXTILineConfig(BUTTON_PORT_SOURCE[Button], BUTTON_PIN_SOURCE[Button]);

    /* Configure Button EXTI line */
	  EXTI_DeInit();
    EXTI_InitStructure.EXTI_Line = EXTI_Line0;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);

    /* Enable and set Button EXTI Interrupt to the lowest priority */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x0F;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

    NVIC_Init(&NVIC_InitStructure); 
}


void SysConfig(void)
{

  /* Reset the RCC clock configuration to the default reset state(for debug purpose) */
  /* Set HSION bit */
  RCC->CR |= (uint32_t)0x00000001;

  /* Reset SW, HPRE, PPRE1, PPRE2, ADCPRE and MCO bits */
  RCC->CFGR |= (uint32_t)0x051C0000;
  
  /* Reset HSI_ON, CSS_ON and PLL_ON bits */
  RCC->CR |= (uint32_t)0x01080001;

  /* Reset PLLSRC, PLLXTPRE, PLLMUL and USBPRE/OTGFSPRE bits */
//  RCC->CFGR &= (uint32_t)0xFF80FFFF;

  /* Disable all interrupts and clear pending bits  */
  RCC->CIR = 0x009F0000;

    

}



void Led_Blink(uint16_t how_much, uint16_t period)
{
	while (how_much != 0)
		{
			GPIO_SetBits(GPIOB, GPIO_Pin_7);
			
			while (Led_Flag != 20)
				{};
					
			Led_Flag = 0;
			GPIO_ResetBits(GPIOB, GPIO_Pin_7);
					
			while (Led_Flag != period)
				{};
					
			Led_Flag = 0;
			how_much--;	
		};
}





